

function App() {

  return (
    <>
      <h1>ClassBot-V2</h1>
    </>
  )
}

export default App
